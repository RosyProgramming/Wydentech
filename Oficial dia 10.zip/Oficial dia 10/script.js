$("#toolbox-tooltip").delay(2500).queue(function(){
  $(this).addClass("show").dequeue();
  next();
});

$("#toolbox-tooltip").delay(5000).fadeOut("slow", function() {
    $(this).removeClass("show");
});


function play_options() {
  document.getElementById("play-dropdown").classList.toggle("show");
}

window.onclick = function(event) {
  if (!event.target.matches('#play-button')) {
    var dropdowns = document.getElementsByClassName("play-dropdown");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}

function toolbox_options() {
  document.getElementById("toolbox-tooltip").classList.toggle("show");
}


$(document).ready(function(){
    $( "#categories" ).click(function( event ) {
        event.preventDefault();
        $("html, body").animate({ scrollTop: $($(this).attr("href")).offset().top }, 800);
    });
    $( "a" ).click(function( event ) {
        event.preventDefault();
        $("html, body").animate({ scrollTop: $($(this).attr("href")).offset().top }, 800);
    });
});

$(window).scroll(function() {    
  var scroll = $(window).scrollTop();

  if (scroll >= 250) {
    $("#categories").addClass("scroll-check");
    $("#slideshow").addClass("slideshow-visible");
  }
  else {
    $("#categories").removeClass("scroll-check");
    $("#slideshow").removeClass("slideshow-visible");
  }
  
});


$('.t-box').hover(
       function(){ $('.t-box').removeClass('hover-t-box') },
       function(){ $(this).addClass('hover-t-box') }
)



var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function setDivs(n) {
  showDivs(slideIndex = n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("slide");
  if (n > x.length) {slideIndex = 1}
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  x[slideIndex-1].style.display = "flex";  
}


var today = new Date();
if(today.getDay() == 1) {
  $('.time-part').each(function(i) {
      if ( i === 0 ) {
         $(this).addClass('today');
      }
  }); 
}
if(today.getDay() == 2) {
  $('.time-part').each(function(i) {
      if ( i === 1 ) {
         $(this).addClass('today');
      }
  }); 
}
if(today.getDay() == 3) {
  $('.time-part').each(function(i) {
      if ( i === 2 ) {
         $(this).addClass('today');
      }
  }); 
}
if(today.getDay() == 4) {
  $('.time-part').each(function(i) {
      if ( i === 3 ) {
         $(this).addClass('today');
      }
  }); 
}
if(today.getDay() == 5) {
  $('.time-part').each(function(i) {
      if ( i === 4 ) {
         $(this).addClass('today');
      }
  }); 
}

var today = new Date().getHours();
if (today >= 8 && today <= 15) { //15 goes up to 15:59:59
  $(".today").addClass("available");
} else {
  $(".today").removeClass("available");
}


// FAQ


$(".open").click(function() {
  var container = $(this).parents(".topic");
  var answer = container.find(".answer");
  var trigger = container.find(".faq-t");

  answer.slideToggle(200);

  if (trigger.hasClass("faq-o")) {
    trigger.removeClass("faq-o");
  } else {
    trigger.addClass("faq-o");
  }

  if (container.hasClass("expanded")) {
    container.removeClass("expanded");
  } else {
    container.addClass("expanded");
  }
});

jQuery(document).ready(function($) {
  $('.question').each(function() {
    $(this).attr('data-search-term', $(this).text().toLowerCase() + $(this).find("ptag").text().toLowerCase());

  });

  $('.live-search-box').on('keyup', function() {

    var searchTerm = $(this).val().toLowerCase();

    $('.question').each(function() {

      if ($(this).filter('[data-search-term *= ' + searchTerm + ']').length > 0 || searchTerm.length < 1) {
        $(this).parent().parent().show();
      } else {
        $(this).parent().parent().hide();
      }

    });

  });

});